package com.infinite.train;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.infinite.hikari.HikariTest;


@Controller
public class InsertController {

	@RequestMapping("/insert")
	public String insert(HttpServletRequest request, HttpServletResponse response) {

		String Username = request.getParameter("Username");
		String Password = request.getParameter("Password");
		String Id = request.getParameter("Id");
		String Age = request.getParameter("Age");
		// String Code=request.getParameter("Code");
		System.out.println("inserted");

		Connection connection = null;
		PreparedStatement pstmt = null;
		try {
			DataSource dataSource = HikariTest.getDataSource();
			connection = dataSource.getConnection();
			pstmt = connection.prepareStatement("insert into train values(?,?,?,?)");
			pstmt.setString(1, Username);
			pstmt.setString(2, Password);
			pstmt.setString(3, Id);
			pstmt.setString(4, Age);
			// pstmt.setString(5,Code);
			int a = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			return "failure";
		}
		return "success";
	}
}
